# -*- coding: utf-8 -*-
import os
import sys

try:
    from urllib.parse import urlparse, urlencode
    from urllib.request import urlopen, Request
    from urllib.error import HTTPError
except ImportError:
    from urlparse import urlparse
    from urllib import urlencode
    from urllib2 import urlopen, Request, HTTPError


import re
import xbmc
import xbmcgui
import xbmcvfs
import xbmcaddon
import xbmcplugin
import plugintools
import unicodedata
import base64
import requests
import shutil
import base64
import time
import six
import random
from datetime import date
from datetime import datetime
try:
    from resolveurl.lib import jsunpack 
except ImportError:
    from resolveurl.plugins.lib import jsunpack 
from resources.modules import control

if six.PY3:
    unicode = str
translatePath = xbmc.translatePath if six.PY2 else xbmcvfs.translatePath

#PY3=False
#if sys.version_info[0] >= 3: PY3 = True; unicode = str; unichr = chr; long = int
addon = xbmcaddon.Addon()
addonname = '[COLOR white]Medusa-Mac[/COLOR]'
icon = addon.getAddonInfo('icon')
myaddon = xbmcaddon.Addon("plugin.video.medusamac")
#px={"http": "http://14.139.189.213:3128"}
px=''
local_file=translatePath('special://home/addons/plugin.video.medusamac/proxy.dat')

## Fotos
thmb_nada=''
thmb_ver_canales='https://raw.githubusercontent.com/MedusaKodi/TV.txt/master/1.jpg'
thmb_ver_vod='https://raw.githubusercontent.com/MedusaKodi/TV.txt/master/1.jpg'
thmb_cambio_servidor='https://raw.githubusercontent.com/MedusaKodi/TV.txt/master/1.jpg'
thmb_cambio_mac='https://raw.githubusercontent.com/MedusaKodi/TV.txt/master/1.jpg'
thmb_carga_servidores=''
thmb_guarda_servidores=''
thmb_nuevo_servidor=''
thmb_guia=''
fanny=""
fanart_guia=""
backgr=""
thmb_ver_set=''
thmb_ver_xc=''
thmb_ver_stb=''
thmb_ver_m3u=''
thmb_about=''
thmb_radio=''
fnrt_radio=''
thmb_help=''
thmb_ace=''
thmb_tube=''

portal = control.setting('portal')
mac = control.setting('mac')
userp = control.setting('userp')
portalxc = control.setting('portalxc')
usernamexc = control.setting('usernamexc')
passxc = control.setting('passxc')
f4mproxy = control.setting("f4mproxy")


mislogos = translatePath(os.path.join('special://home/addons/plugin.video.medusamac/jpg/'))
logo_transparente = translatePath(os.path.join(mislogos , 'transparente.png'))

setting = xbmcaddon.Addon().getSetting


def keyboard_input(default_text="", title="", hidden=False):

    keyboard = xbmc.Keyboard(default_text,title,hidden)
    keyboard.doModal()
    
    if (keyboard.isConfirmed()):
        tecleado = keyboard.getText()
    else:
        tecleado = ""

    return tecleado

def run_old():
    #
    
    # Get params
           
    params = plugintools.get_params()
    
    if params.get("action") is None:
        if PY3==False:
            xbmc.executebuiltin('Container.SetViewMode(51)')        
        
        main_list(params)
    else:
       if PY3==False:
           xbmc.executebuiltin('Container.SetViewMode(51)') 
       action = params.get("action")
       url = params.get("url")
       exec (action+"(params)")

    plugintools.close_item_list()
    
def run():
    
    plugintools.log("---> macvod.run <---")
    #plugintools.set_view(plugintools.LIST)
    
    # Get params
    params = plugintools.get_params()
    
    if params.get("action") is None:
        main_list(params)
    else:
       action = params.get("action")
       url = params.get("url")
       exec(action+"(params)")
    plugintools.close_item_list()

def cambia_fondo():

    foto = translatePath('special://home/addons/plugin.video.medusamac/fondo.jpg')    
    if not xbmc.getCondVisibility('Skin.String(CustomBackgroundPath)'):      
        xbmc.executebuiltin('Skin.Reset(CustomBackgroundPath)')
        xbmc.executebuiltin('Skin.SetBool(UseCustomBackground,True)')   
        xbmc.executebuiltin('Skin.SetString(CustomBackgroundPath,'+foto+')')
        xbmc.executebuiltin('ReloadSkin()')
    
def main_list(params):
    proxy=params.get('extra')
    import shutil,xbmc  
    try:
        addon_path3 = translatePath('special://home/cache').decode('utf-8')
        shutil.rmtree(addon_path3, ignore_errors=True) 
    except:
        pass
    
    cambia_fondo()
        
    plugintools.log("medusamac.main_list ")    
    params['title']="[COLOR red]i[COLOR orange]P[COLOR green]TV[COLOR orange] CHaNNeLS[/COLOR]"
    params['thumbnail']=thmb_ver_canales
    params['fanart']=""
    mac=myaddon.getSetting('mac')
    portal=myaddon.getSetting('portal')
    
    if userp=="":
        userpast = userpastebin()
        control.setSetting('userp',userpast)
        xbmc.executebuiltin('Container.Refresh')
        cambio_servidor(params)
    else:
        macpastebin(params)
		

def settings(params): 
    plugintools.open_settings_dialog()
    xbmc.executebuiltin('Container.Refresh')
	
def macpastebinx(params):
    if userp=="":
        userpast = userpastebin()
        control.setSetting('userp',userpast)
        xbmc.executebuiltin('Container.Refresh')
        cambio_servidor(params)
    else:
        macpastebin(params)
		
def userpastebin():
    kb = xbmc.Keyboard('', 'heading', True)
    kb.setHeading('CONT PASTEBIN')
    kb.setHiddenInput(False)
    kb.doModal()
    if kb.isConfirmed():
        text = kb.getText()
        return text
    else:
        return False
	


def macpastebin(params):
    import shutil,xbmc  
    try:
        addon_path3 = translatePath('special://home/cache').decode('utf-8')
        shutil.rmtree(addon_path3, ignore_errors=True) 
    except:
        pass
    
    cambia_fondo()
        
    escogido=myaddon.getSetting('escogido')
    mac=myaddon.getSetting('mac2')
    


    plugintools.log("medusamac.macpastebin")    
    plugintools.add_item(action="ver_canales",    title="TV & Vod Kanäle",thumbnail=thmb_ver_canales,fanart="",folder= True )                
    plugintools.add_item(action="cambio_servidor",    title="Server Auswahl:   "+escogido,thumbnail=thmb_cambio_servidor,fanart="",folder= True )               
    plugintools.add_item(action="cambio_mac",         title="MAC Auswahl:   "+mac,thumbnail=thmb_cambio_mac,fanart="",folder= True )
    
def macx(params):
    if portal=="":
        portp = portpopup()
        macn = macpopup()
        control.setSetting('portal',portp)
        control.setSetting('mac',macn)
        xbmc.executebuiltin('Container.Refresh')
        mac2(params)
    else:
        mac2(params)
        
def macxadd(params):
    portp = portpopup()
    macn = macpopup()
    control.setSetting('portal',portp)
    control.setSetting('mac',macn)
    xbmc.executebuiltin('Container.Refresh')
    mac2(params)
		
def macpopup():
    kb = xbmc.Keyboard('', 'heading', True)
    kb.setHeading('MAC')
    kb.setHiddenInput(False)
    kb.doModal()
    if kb.isConfirmed():
        text = kb.getText()
        return text
    else:
        return False

def portpopup():
    kb =xbmc.Keyboard ('', 'heading', True)
    kb.setHeading('PORTAL')
    kb.setHiddenInput(False)
    kb.doModal()
    if kb.isConfirmed():
        text = kb.getText()
        return text
    else:
        return False	

def mac2(params):
    plugintools.log("macovd.mac")    
    mac=myaddon.getSetting('mac')
    portal=myaddon.getSetting('portal')
	
    plugintools.add_item( action="tombola", title="[COLOR orange]Canale IPTV[/COLOR]", thumbnail = thmb_ver_canales, fanart= backgr,page=mac,url=portal,folder=True )
    
    plugintools.add_item( action="pelis", title="[COLOR orange]VOD[/COLOR]", thumbnail = thmb_ver_vod, fanart= backgr,page=mac,url=portal,folder=True )


def tombola(params):
    import xbmc, time

    thumbnail = params.get("thumbnail") 
    portal = params.get("url")  
    mac = params.get("page")     
    s=''
    usuario = ''
    def macs(s):
        import requests,re
        headers = {"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:84.0) Gecko/20100101 Firefox/84.0","cookie": "mac="+mac+"; stb_lang=es; timezone=Europe/spain"}
        url=portal+'portal.php?type=stb&action=handshake&JsHttpRequest=1-xml'
        source=requests.get(url, headers=headers).text
 
        return source
    token =macs(s)
    token=re.findall('token":"(.*?)"',token)[0]
    token=str(token)    
    def macs(s):
        import requests,re    
        headers = {"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:84.0) Gecko/20100101 Firefox/84.0","cookie": "mac="+mac+"; stb_lang=es; timezone=Europe/spain","Authorization": "Bearer "+token}
        url=portal+'portal.php?type=stb&action=get_profile&JsHttpRequest=1-xml'
        source=requests.get(url, headers=headers).text
        passs=re.findall('login":"","password":"(.*?)"',source )[0]
        typee=re.findall('"stb_type":"(.*?)"',source )[0]
        payload={"login":usuario,"password":passs,"stb_type":typee}
        headers = {"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:84.0) Gecko/20100101 Firefox/84.0","cookie": "mac="+mac+"; stb_lang=es; timezone=Europe/spain","Authorization": "Bearer "+token}
        url=portal+'portal.php?type=itv&action=get_genres&JsHttpRequest=1-xml'
        s = requests.Session()
        source=s.post(url, headers=headers,data=str(payload)).text
        return source
    source=macs(s)
    data = plugintools.find_multiple_matches(source,'("id":"\d+.*?".*?"title":".*?",")')   
 
 
    for generos in data: 
        patron=plugintools.find_single_match(generos,'"id":"(\d+.*?)".*?"title":"(.*?)"') 
        titulo=patron[1]
        titulo=titulo.replace('\\u2b50','').replace('\\/','/')
        ids=patron[0]
        if  ('romania' in titulo.lower() or 'roumania' in titulo.lower() or 'EU- RO' in titulo):               
            color='lime'
            titulo='[LOWERCASE][CAPITALIZE][COLOR '+color+']'+titulo+'[/CAPITALIZE][/LOWERCASE][/COLOR]'           
        
        else:               
            color='white'
            titulo='[LOWERCASE][CAPITALIZE][COLOR '+color+']'+titulo+'[/CAPITALIZE][/LOWERCASE][/COLOR]'             

        if  ('adultxxxxxxxxx' in titulo.lower()):                        
                 
             titulo=' [LOWERCASE][CAPITALIZE][COLOR fuchsia]'+patron[1]+' seccion x[/CAPITALIZE][/LOWERCASE][/COLOR]'
             dialog = xbmcgui.Dialog()
             ret = dialog.select('[COLOR yellow]CONTIENE CANALES ADULTOS NECESITA CLAVE,¿QUE QUIERES?:[/COLOR]', ['[COLOR lime]METER LA CLAVE Y DISFRUTAR DE ELLOS[/COLOR]', '[COLOR aqua]NO QUIERO  LOS CANALES ADULTOS[/COLOR]'])
             lists = ['si', 'no']
             eleccion = lists[ret]
             if 'no' in eleccion:                 
                           
                 ids='99999999999'  
             if 'si' in eleccion:
                 dialog = xbmcgui.Dialog()
                 d = dialog.input('[B][LOWERCASE][CAPITALIZE][COLOR orange]meter la clave: [COLOR orange]si no la tienes pideta en telegram @tvchopo[/COLOR][/CAPITALIZE][/LOWERCASE][/B]', type=xbmcgui.INPUT_ALPHANUM).replace(" ", "+")
                 if 'x69' in d:
                     ids=ids
                 else:
                     xbmcgui.Dialog().ok('[COLOR orange]LA CLAVE ES INCORRECTA[/COLOR]', '[LOWERCASE][CAPITALIZE][COLOR orange]METE LA CLAVE EN MINUSCULA\nSI NO LO CONSIGUES ESTAMOS EN TELEGRAM [COLOR orange]@TVCHOPO[/COLOR][/CAPITALIZE][/LOWERCASE]')  
        plugintools.add_item( action="lista2", title="[COLOR orange]"+titulo+"[/COLOR]", thumbnail = params.get("thumbnail"), fanart= params.get("thumbnail"),plot=token,page=mac,extra=portal,url=ids,folder=True )


def lista2(params):
    
    ids = params.get("url")
    portal = params.get("extra")
    mac = params.get("page")
    token = params.get("plot")
    headers = {"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:84.0) Gecko/20100101 Firefox/84.0","cookie": "mac="+mac+"; stb_lang=es; timezone=Europe/spain","Authorization": "Bearer "+token}
    pb  = xbmcgui.DialogProgress()
    pb.create('Kanäle werden geladen ','')
    count=40;pn=1;data=[]
    while pn <= int(count):
        page=portal+'portal.php?type=itv&action=get_ordered_list&genre='+ids+'&force_ch_link_check=&fav=0&sortby=number&hd=0&p='+str(pn)+'&JsHttpRequest=1-xml'
        try:
            source=requests.get(page, headers=headers).text            
            data +=re.findall('"id":".*?","name":"(.*?)".*?"ch_id":"(.*?)"',source);pn +=1
        except:
            break
            
    i=1
    total=len(data)
    for patron in sorted(data, key=lambda patron: patron[0]):         
        canal=str(patron[1])               
        titulo=str(patron[0]).replace('\u00ed','i').replace('\u00eda','e').replace('\u00f1','ñ').replace('\u00fa','u').replace('\u00f3','o').replace('\u00c1','a').replace('\u00e9','e').replace('\u00e1','a').replace('\\','') 
        #titulo=str(patron[0])
        pb.update(int(100*i/140),str(100*i/total)+'% - Canal '+titulo)         
        plugintools.add_item( action="lista3",extra=str(portal),url=canal,page=mac,plot=params.get("plot"),title="[LOWERCASE][CAPITALIZE][COLOR white]"+colorea(titulo)+"[/CAPITALIZE][/LOWERCASE][/COLOR]", thumbnail = params.get("thumbnail"), fanart= params.get("thumbnail"),folder=False,  isPlayable = True )         
        i+=1
        
    pb.close()    
    
    
def lista3(params):
    canal = params.get("url")
    portal = params.get("extra")  
    mac = params.get("page")
    titulo1 = params.get("plot")
    headers =headers = {"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:84.0) Gecko/20100101 Firefox/84.0","cookie": "mac="+mac+"; stb_lang=es; timezone=Europe/spain","Authorization": "Bearer "+titulo1}
    url=portal+'portal.php?type=itv&action=create_link&cmd=http://localhost/ch/'+canal+'_&series=&forced_storage=undefined&disable_ad=0&download=0&JsHttpRequest=1-xml'
    source=requests.get(url, headers=headers).text
    token=re.findall('"cmd":"ffmpeg (.*?)"',source )[0]
    url=token.replace("\\", "")
    url=url
    plugintools.play_resolved_url(url)


def pelis(params):
    import xbmc, time
    portal = params.get("url")
    mac = params.get("page")
    s=''
    usuario = ''
    def macs(s):
        import requests,re
        headers = {"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:84.0) Gecko/20100101 Firefox/84.0","cookie": "mac="+mac+"; stb_lang=es; timezone=Europe/spain"}
        url=portal+'portal.php?type=stb&action=handshake&JsHttpRequest=1-xml'
        source=requests.get(url, headers=headers).text
 
        return source
    token =macs(s)
    token=re.findall('token":"(.*?)"',token)[0]
    token=str(token)    
    def macs(s):
        import requests,re    
        headers = {"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:84.0) Gecko/20100101 Firefox/84.0","cookie": "mac="+mac+"; stb_lang=es; timezone=Europe/spain","Authorization": "Bearer "+token}
        url=portal+'portal.php?type=stb&action=get_profile&JsHttpRequest=1-xml'
        source=requests.get(url, headers=headers).text
        passs=re.findall('login":"","password":"(.*?)"',source )[0]
        typee=re.findall('"stb_type":"(.*?)"',source )[0]
        payload={"login":usuario,"password":passs,"stb_type":typee}
        headers = {"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:84.0) Gecko/20100101 Firefox/84.0","cookie": "mac="+mac+"; stb_lang=es; timezone=Europe/spain","Authorization": "Bearer "+token}
        url=portal+'portal.php?type=vod&action=get_categories&JsHttpRequest=1-xml'
        s = requests.Session()
        source=s.post(url, headers=headers,data=str(payload)).text
        return source
    source=macs(s)
    data = plugintools.find_multiple_matches(source,'("id":"\d+.*?".*?"title":".*?",")')   
 
 
    for generos in data: 
        patron=plugintools.find_single_match(generos,'"id":"(\d+.*?)".*?"title":"(.*?)"') 
        titulo=patron[1]
        titulo=titulo.replace('\\u2b50','')
        ids=patron[0]

        plugintools.add_item( action="pelis2", title="[COLOR orange]"+titulo+"[/COLOR]", thumbnail = params.get("thumbnail"), fanart= params.get("thumbnail"),plot=token,page=mac,extra=portal,url=ids,folder=True )
def pelis2(params):
    s=''
    ids = params.get("url")
    portal = params.get("extra")
    mac = params.get("page")
    token = params.get("plot")
    headers = '{"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:84.0) Gecko/20100101 Firefox/84.0","cookie": "mac="'+mac+'"; stb_lang=es; timezone=Europe/spain","Authorization": "Bearer "'+token+'}'
    def macs(s):
 
        count=40;pn=1;data=[]
        while pn <= int(count):
            headers = {"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:84.0) Gecko/20100101 Firefox/84.0","cookie": "mac="+mac+"; stb_lang=es; timezone=Europe/spain","Authorization": "Bearer "+token}
            page=portal+'portal.php?type=vod&action=get_ordered_list&genre='+ids+'&force_ch_link_check=&fav=0&sortby=number&hd=0&p='+str(pn)+'&JsHttpRequest=1-xml';source=requests.get(page, headers=headers).content.decode('ascii','ignore')
            data +=re.findall('("id":".*?".*?,"name":".*?".*?.*?"description":".*?".*?"year":".*?".*?screenshot_uri":".*?".*?_str":".*?","cmd":".*?")',source);pn +=1
        return data
    
    url=macs(s)
    for generos in url: 
        patron = plugintools.find_single_match(generos,'"id":".*?".*?,"name":"(.*?)".*?.*?"description":"(.*?)".*?"year":"(.*?)".*?screenshot_uri":"(.*?)".*?_str":"(.*?)","cmd":"(.*?)"')
        foto=patron[3].replace("\\", "")
        titulo=patron[0].replace("\\u00f1", "n")
        titulo=titulo.replace('\\/','').replace('\u2b50','')
        texto=patron[1]
        year=patron[2].replace('N\\/A','')
        canal=patron[5]
        plugintools.add_item( action="pelis3",extra=portal,url=canal,page=mac,plot=params.get("plot"),title="[LOWERCASE][CAPITALIZE][COLOR orange]"+titulo+" [COLOR yellow]"+year+"[/CAPITALIZE][/LOWERCASE][/COLOR]", thumbnail = foto, fanart= foto,folder=False,  isPlayable = True ) 
  
def pelis3(params):
    s=''
    canal = params.get("url")
    portal = params.get("extra")
    mac = params.get("page")

    def macs(s):
        import requests,re  
        headers =headers = {"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:84.0) Gecko/20100101 Firefox/84.0","cookie": "mac="+mac+"; stb_lang=es; timezone=Europe/spain","Authorization": "Bearer "+params.get("plot")}
        url=portal+'portal.php?type=vod&action=create_link&cmd='+canal+'_&forced_storage=undefined&disable_ad=0&download=0&JsHttpRequest=1-xml'
        source=requests.get(url, headers=headers).text
        token=re.findall('"cmd":"ffmpeg (.*?)"',source )[0]
        source= token.replace("\\", "")
        return source
    url=macs(s)
    url=url
    plugintools.play_resolved_url(url)
	

def resolve_without_resolveurl ( params ) :
    import resolveurl 
    url = (params.get ( "url" ))
    finalurl = url.encode("utf-8", "strict")
    plugintools.play_resolved_url ( finalurl ) 
    

#code macpastebin
#code macpastebin


def ver_canales(params):
      
    thumbnail = params.get("thumbnail")
    
    mac=myaddon.getSetting('mac2')
    portal=myaddon.getSetting('portal2')
    escogido=myaddon.getSetting('escogido')
    s=''
    usuario = ''
  
    headers = {"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:84.0) Gecko/20100101 Firefox/84.0","cookie": "mac="+mac+"; stb_lang=es; timezone=Europe/spain"}
    url=portal+'portal.php?type=stb&action=handshake&JsHttpRequest=1-xml'
        
    source=''
    
    try:
        source = requests.Session()
        source=requests.get(url, headers=headers).content
    except:
    
        xbmc.executebuiltin('XBMC.Notification( Nu se poate conecta la SERVER: ' + escogido +', '+portal+' '+mac+ ', 8000)')            
    
    if source =='':
        xbmc.executebuiltin('XBMC.Notification( Nu se poate conecta la SERVER: ' + escogido +', '+str(source)+ ', 8000)')  
        #xbmc.log('ERROR conectando al servidor: '+str(source)+' : '+str(url))
        #xbmc.executebuiltin('Action(Back)')
        #return(params)
    
    token=''
    try:
        token=re.findall('token":"(.*?)"', str(source) )[0] 
    except:       
        xbmc.executebuiltin('XBMC.Notification( Nu se poate conecta la SERVER: ' + escogido +', '+str(source)+ ', 8000)')  
        #xbmc.executebuiltin('Action(Back)')
        #return(params)
    
    headers = {"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:84.0) Gecko/20100101 Firefox/84.0","cookie": "mac="+str(mac)+"; stb_lang=es; timezone=Europe/spain","Authorization": "Bearer "+token}
    url=portal+'portal.php?type=stb&action=get_profile&JsHttpRequest=1-xml'
    urlval=portal+'portal.php?type=account_info&action=get_main_info&JsHttpRequest=1-xml'
    source=""
    
    usuario=''
    
    source = requests.Session()           
    source=requests.get(url, headers=headers).content
    
    try:
        passs=re.findall('login":"","password":"(.*?)"',source )[0]
        typee=re.findall('"stb_type":"(.*?)"',str(source) )[0]
    except:
        passs=''
        usuario=''
        typee=''
            
    payload={"login":usuario,"password":passs,"stb_type":typee}
    headers = {"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:84.0) Gecko/20100101 Firefox/84.0","cookie": "mac="+mac+"; stb_lang=es; timezone=Europe/spain","Authorization": "Bearer "+token}
    url=portal+'portal.php?type=itv&action=get_genres&JsHttpRequest=1-xml'
        
    source=''
    
    s = requests.Session()                
    source=s.post(url, headers=headers,data=str(payload)).text
    sourceval=s.post(urlval, headers=headers,data=str(payload)).text
    
    if source!='':
        
        data = plugintools.find_multiple_matches(source,'("id":"\d+.*?".*?"title":".*?",")') 
        dataval = plugintools.find_multiple_matches(sourceval,'("phone"\:".+?")')  
        for generosval in dataval: 
            patron=plugintools.find_single_match(generosval,'"phone"\:"(.+?)"')
            validitate=patron
            pr0n=myaddon.getSetting('pr0n')  
            plugintools.add_item(title='[COLOR blue]'+validitate+'[/COLOR]',folder=False, isPlayable=False)
            plugintools.add_item(title='[COLOR gray][/COLOR]',folder=False, isPlayable=False) 
            plugintools.add_item( action="pelis", title='[COLOR orange]VOD Kanäle: [ '+mac+' ][/COLOR]', thumbnail = thmb_ver_vod, fanart= backgr,page=mac,url=portal,folder=True )
            plugintools.add_item(title='[COLOR gray][/COLOR]',folder=False, isPlayable=False) 
        for generos in data: 
            
            patron=plugintools.find_single_match(generos,'"id":"(\d+.*?)".*?"title":"(.*?)"') 
            titulo=patron[1]
            ids=patron[0]
                        
            tit=colorea(titulo)
            
            if  not('adult' in titulo.lower() and pr0n=="false"):                            
                #plugintools.add_item(action="paginar_canales", title=tit, thumbnail = params.get("thumbnail"), fanart= params.get("thumbnail"),plot=token,page=mac,extra=portal,url=ids,folder=True)                         
                plugintools.add_item(action="lista2", title=tit, thumbnail = params.get("thumbnail"), fanart= params.get("thumbnail"),plot=token,page=mac,extra=portal,url=ids,folder=True)
    else:
        xbmc.executebuiltin('XBMC.Notification([COLOR red]Problema '+'[COLOR orange]'+escogido+'[/COLOR],[COLOR orange]'+portal+' '+mac+'[/COLOR], 10000)')            
        
def cambio_servidor(params):

    server2=myaddon.getSetting('ser')
    escogido=myaddon.getSetting('escogido')
    userp=myaddon.getSetting('userp')
    portal= myaddon.getSetting('portal2')
    mac= myaddon.getSetting('mac2')
    dialog = xbmcgui.Dialog()
    
    
    #lists=myaddon.getSetting('lista').split(',')
    #lista_servidores=myaddon.getSetting('lista_servidores').split(',')
    listaservere = urlopen(Request("https://pastebin.com/u/"+userp)).read().decode('utf-8')
    lists = re.findall('(?s)data-key=".+?".+?href="/(.+?)".+?</div', listaservere) 
    #lists=lista
    lista_servidores= re.findall('(?s)data-key=".+?".+?href=".+?">(.+?)<.+?</div', listaservere)
	
	
    retorno = dialog.select('[COLOR blue]Momentaner Server: [/COLOR]'+str(escogido), lista_servidores)

        
        #if retorno<>-1:
        #xbmc.executebuiltin('XBMC.Notification(Lista,'+lista_servidores[retorno]+',8000)')
        
    dialog = xbmcgui.Dialog()    
        
    if str(retorno)!='-1':   
        server2=lists[retorno]
        escogido=lista_servidores[retorno]
        if 1==1: #try:     
            
            mac1 = urlopen(Request("https://pastebin.com/raw/"+server2)).read().decode('utf-8')
            
            mac=""
            mac=re.findall('(00:.*?79:.*?........)', mac1)            
            portal=re.findall('portal"(.*?)"', mac1.lower())[0]
            maclista=''
            random.seed()
            
            while maclista == '' or not maclista:
                maclista = random.choice(mac)
        
            mac=maclista                
            myaddon.setSetting('mac2',mac)
            myaddon.setSetting('portal2',portal)
            myaddon.setSetting('ser',server2)
            myaddon.setSetting('escogido',escogido)
        else:
        #except:
            xbmc.executebuiltin('XBMC.Notification( Eroare la deschiderea: ' + str(escogido) +', '+str(portal)+' '+str(mac)+ ', 8000)')               
            xbmc.executebuiltin('Action(Back)')        
    else:
        xbmc.executebuiltin('Action(Back)')        

    xbmc.executebuiltin('Content.refresh')
    ver_canales(params)        


def cambio_mac(params):
       
    try:
        server2 = myaddon.getSetting('ser')
        macant= myaddon.getSetting('mac2')
        escogido= myaddon.getSetting('escogido')
    except:
        server2='7c1PF9Ya'#aqui
    if escogido=='Fisier_LOCAL':
        xbmc.executebuiltin('XBMC.Notification(Fisier local, Fisierul LOCAL functioneaza cu un singur MAC. Daca doresti sa schimbi MAC-ul adauga o noua linie in fisierul local. , 8000)')                        
        xbmc.executebuiltin('Content.Refresh')
        xbmc.executebuiltin('Action(Back)')
    
    else:

        try:    
            mac1 = urlopen(Request("https://pastebin.com/raw/"+server2)).read().decode('utf-8')
            mac=""
            mac=re.findall('(00:.*?79:.*?........)', mac1)
            portal=re.findall('portal"(.*?)"', mac1.lower())[0]
            dialog = xbmcgui.Dialog()
            ret = dialog.select('Momentane MAC: [ '+str(escogido)+' # '+str(macant)+' ]', ['Mac jetzt ändern', 'Weiter mit derzeitiger MAC '+macant])
            lists = ['si','no']
    
            categorias= lists[ret]
                
            if 'si' in categorias:
                newmac=''
            
                selectable="Zufällige MAC"
                for mc in mac:                                    
                        selectable=selectable+','+str(mc)
                
                lista_macs=selectable.split(",")
                ret=dialog.select('Mac Auswahl:',lista_macs)

                if ret==1:
                    random.seed()
                    while newmac == '' or not newmac:
                        newmac = random.choice(mac)                      
                else:
                    if ret==-1:
                        newmac=macant
                    else:
                        newmac=mac[ret-1]

                if newmac!=macant:
                        myaddon.setSetting('mac2',newmac)
                        xbmc.executebuiltin('XBMC.Notification( MAC nou, ' +newmac+ ', 8000)')                        
    
        except:
                xbmc.executebuiltin('XBMC.Notification( Eroare MAC nou, Se continua cu' +macant+ ', 8000)')    
                xbmc.executebuiltin('Action(Back)')        

        xbmc.executebuiltin('Content.refresh')
        ver_canales(params)
        
def colorea(titulo):

    if  'Romania' in titulo.lower() or 'rom' in titulo.lower() or 'EU -RO' in titulo or 'romanian' in titulo.lower() or 'EU- RO' in titulo:               
        color='darkorange'                                             
    else:
        if 'crimexxx' in titulo.lower():
            color='springgreen'
        else:
            if 'axnxxxxxx' in titulo.lower()  or 'accionxxxxxxx' in titulo.lower() or 'estrenosxxxxx'  in titulo.lower() or 'historiaxxxxxxx'  in titulo.lower() or 'odiseaxxxxxxxx'  in titulo.lower() or 'discoveryxxxxxxx'  in titulo.lower():
                    color='deeppink'
            else:        
                if 'adult' in titulo.lower() or 'xxx' in titulo.lower() or 'porn' in titulo.lower():
                    color='red'
                else:
                    color='mintcream'
    
    return '[COLOR '+color+']'+titulo+'[/COLOR]'
    

def tulista(params):
    dhoy=date.today()
    text_today = dhoy.strftime("%Y%m%d")        
    hoy=int(text_today)
    try:
        mac=myaddon.getSetting('cam')      
        server=myaddon.getSetting('revres')
        portal=myaddon.getSetting('latrop')
        userp=myaddon.getSetting('userp')
        nat=int(myaddon.getSetting('nat'))
        fec_texto=myaddon.getSetting('fec')
        fec=int(fec_texto)
    except:
        nat=10
        mac=''
        server=''
        portal=''
        myaddon.setSetting('cam',mac)
        myaddon.setSetting('revres',server)
        myaddon.setSetting('latrop',portal)
        myaddon.setSetting('nat',str(nat))
        myaddon.setSetting('fec',text_today)
        fec = hoy
    
    if fec < hoy:     
        nat=10
    
    maximo=False
    if nat<=0:
        xbmcgui.Dialog().ok('MAXIMUM number of lists reached ', 'You have reached the maximum number of lists to use today. You have to wait until tomorrow to be able to use the list again. We leave you with your last list for today ')
        maximo=True
        #xbmc.executebuiltin('Action(Back)')
        #return
    
    #Guardo el nº de veces = nº de veces-1 y guardo la fecha actual
    
    if fec==hoy and maximo==False:
        dialog = xbmcgui.Dialog()
        ret = dialog.select('Selecciona opcion', ['[COLOR red]CREATE NEW LIST [/COLOR]       [ You have left [COLOR green]'+str(nat)+'[/COLOR] attempt ]', '[COLOR white]Continue with TODAY list[/COLOR]'])
        #ret = dialog.select('Selecciona opcion', ['[COLOR red]CREAR LISTA NUEVA[/COLOR]', '[COLOR white]Seguir com mi lista de HOY[/COLOR]'])
    else:
        if maximo==False:
            ret=0
        else:
            ret=1
           
    if ret==0:
        #Lista de Servidores desde pastebin
        #serv = urlopen(Request("https://pastebin.com/raw/a38wUnQf")).read().decode('utf-8')
        listaservere = urlopen(Request("https://pastebin.com/u/"+userp)).read().decode('utf-8')
        serv = re.findall('(?s)data-key=".+?".+?href="/(.+?)".+?</div', listaservere) 
        data=[]
        intento=1
        while data ==[] and intento<=10:
            servidores=re.findall('(?s)data-key=".+?".+?href="/(.+?)".+?</div', listaservere) 
            server = str(random.choice(servidores))
            
            mac,portal=mac_portal(server) 
            
            data,token=get_canales(mac,portal)
            if data!=[]:                
                nat=nat-1   
                myaddon.setSetting('nat',str(nat))
                myaddon.setSetting('cam',mac)
                myaddon.setSetting('revres',server)
                myaddon.setSetting('latrop',portal)
                myaddon.setSetting('fec',text_today)
                
                i=1
                pb=xbmcgui.DialogProgress()
                pb.create('Se incarca canalele','')
                total=len(data)
                for patron in sorted(data, key=lambda patron: patron[1]):         
                    titulo=str(patron[1]).replace('\\','').replace('\u00ed','i').replace('\u00eda','e').replace('\u00f1','ñ').replace('\u00fa','u').replace('\u00f3','o').replace('\u00c1','a').replace('\u00e9','e').replace('\u00d1','Ñ').replace('\u00e1','a')
                    ids=str(patron[0])
                    plugintools.add_item( action="lista2", title="[COLOR white]"+colorea(titulo)+"[/COLOR]", thumbnail = params.get("thumbnail"), fanart= params.get("thumbnail"),plot=token,page=mac,extra=portal,url=ids,folder=True ) 
                    pb.update(int(100*i/total),str(100*i/total)+'% - Se incarca canalul '+str(titulo))
                    i+=1
                
                pb.close()
                
            else:
                intento=intento+1
    
        if intento==3 and data==[]:
            xbmcgui.Dialog().ok('MAXIMUM no. of searching attempts reached', 'Looks like no luck with this list, try your luck with another')
            xbmc.executebuiltin('Action.Back()')
            xbmc.executebuiltin('Content.Refresh()')
            return

    if ret==1:
        try:
            data,token=get_canales(mac,portal)
            for patron in sorted(data, key=lambda patron: patron[1]):         
                titulo=patron[1].replace('\u00ed','i').replace('\u00eda','e').replace('\u00f1','ñ').replace('\u00fa','u').replace('\u00f3','o').replace('\u00c1','a').replace('\u00e9','e').replace('\u00d1','Ñ').replace('\u00e1','a').replace('\\','') 
                ids=str(patron[0])
                
                plugintools.add_item( action="lista2", title="[COLOR white]"+colorea(titulo)+"[/COLOR]", thumbnail = params.get("thumbnail"), fanart= params.get("thumbnail"),plot=token,page=mac,extra=str(portal),url=ids,folder=True ) 
        except:
            xbmc.executebuiltin('Notification(Server down, it seems that this server is not operational ,8000')
            xbmc.executebuiltin('Action(Back)')
    
    if ret==-1:
        xbmc.executebuiltin('Action(Back)')

def quita_favoritos():
    favoritos = translatePath('special://home/userdata/favourites.xml')    
    try:
        f = open(favoritos,'rw')
        favoritos1 = f.readlines()
        for line in favoritos1:
            if not 'portal.php?type=' in line:
                f.write(line)
        f.close()
    except:
        pass
        
def mac_portal(server):
    dhoy=date.today()
    text_today = dhoy.strftime("%Y%m%d")        
    hoy=int(text_today)    
    data=urlopen(Request("https://pastebin.com/raw/"+server)).read().decode('utf-8').lower()
    macx=re.findall('(00:1a:79:.*?........)', data)
    portal=str(re.findall('portal"(.*?)"', data)[0])
    mac =str(random.choice(macx))
    myaddon.setSetting('revres',str(server))
    myaddon.setSetting('cam',str(mac))
    myaddon.setSetting('latrop',str(portal))
    myaddon.setSetting('fec',str(text_today))
    return mac,portal

def get_canales(mac,portal):
    usuario = ''
    headers = {"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:84.0) Gecko/20100101 Firefox/84.0","cookie": "mac="+str(mac)+"; stb_lang=es; timezone=Europe/spain"}
    url=portal+'portal.php?type=stb&action=handshake&JsHttpRequest=1-xml'
    try:
        token =requests.get(url, headers=headers).text
        token=re.findall('token":"(.*?)"',token)[0]
        
        headers = {"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:84.0) Gecko/20100101 Firefox/84.0","cookie": "mac="+mac+"; stb_lang=es; timezone=Europe/spain","Authorization": "Bearer "+token}
        url=portal+'portal.php?type=stb&action=get_profile&JsHttpRequest=1-xml'
        source=requests.get(url, headers=headers).text
        passs=re.findall('login":"","password":"(.*?)"',source )[0]
        typee=re.findall('"stb_type":"(.*?)"',source )[0]
        payload={"login":usuario,"password":passs,"stb_type":typee}
        headers = {"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:84.0) Gecko/20100101 Firefox/84.0","cookie": "mac="+mac+"; stb_lang=es; timezone=Europe/spain","Authorization": "Bearer "+token}
        url=portal+'portal.php?type=itv&action=get_genres&JsHttpRequest=1-xml'
        s = requests.Session()
        source=s.post(url, headers=headers,data=str(payload)).text        
        return plugintools.find_multiple_matches(source,'"id":"(\d+.*?)".*?"title":"(.*?)"'),token 
    except:
        
        return [],[]


run()